# 💹 ValuEdge — Company Valuation & Financial Modeling Platform

ValuEdge is a full-stack finance and business analytics platform for modeling company value using simplified **Discounted Cash Flow (DCF)** and **Comparable Company Analysis**.

## Features
- Company financial profile management
- DCF valuation
- Five-year free-cash-flow projection
- Enterprise value calculation
- Equity value calculation
- Implied value per share
- Comparable-company analysis
- Revenue and EBITDA multiples
- Peer benchmarking
- Valuation dashboard
- SQLite relational database

## Technology
Python, Flask, SQLite, SQL, Jinja2, HTML5, CSS3.

## Run
```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate

pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:5000`.

## Valuation Methodology

### DCF
The demo calculates projected free cash flow for five years and discounts it at an 11% WACC.

```text
FCF = EBITDA − CapEx − Change in Working Capital

PV of FCF = FCF / (1 + WACC)^Year

Terminal Value =
Terminal FCF / (WACC − Terminal Growth)

Enterprise Value =
PV of Forecast FCF + PV of Terminal Value

Equity Value =
Enterprise Value + Cash − Debt

Implied Value Per Share =
Equity Value / Shares Outstanding
```

### Comparable Companies
Peer revenue and EBITDA multiples are averaged and applied to the selected company's financial base to create indicative comparable-company valuation references.

## Project Structure
```text
ValuEdge/
├── app.py
├── requirements.txt
├── README.md
├── schema.sql
└── templates/
    ├── base.html
    ├── dashboard.html
    ├── companies.html
    ├── company_form.html
    └── valuation.html
```

## MBA/Finance Concepts
- Corporate finance
- Financial modeling
- DCF valuation
- Comparable-company analysis
- Enterprise value
- Equity value
- Capital structure
- Growth assumptions
- Cost of capital
- Financial decision support

## Future Enhancements
- WACC calculator
- CAPM module
- Sensitivity tables
- Scenario analysis
- LBO modeling
- Precedent transactions
- Financial statement upload
- Excel/PDF export
- Interactive charts
- PostgreSQL
- Authentication and role-based access
- API integration

Educational/portfolio project. Valuations are illustrative and should not be treated as investment advice.
