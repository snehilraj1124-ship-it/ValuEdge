from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "valuedge-demo-secret"
DB = Path(__file__).with_name("valuedge.db")

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS companies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        sector TEXT NOT NULL,
        revenue REAL NOT NULL,
        ebitda REAL NOT NULL,
        growth REAL NOT NULL,
        capex REAL NOT NULL,
        working_capital REAL NOT NULL,
        cash REAL NOT NULL,
        debt REAL NOT NULL,
        shares REAL NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS comparables (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        peer_name TEXT NOT NULL,
        revenue_multiple REAL NOT NULL,
        ebitda_multiple REAL NOT NULL,
        FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
    );
    """)
    if conn.execute("SELECT COUNT(*) FROM companies").fetchone()[0] == 0:
        conn.execute("""INSERT INTO companies
        (name,sector,revenue,ebitda,growth,capex,working_capital,cash,debt,shares)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        ("Apex Consumer Ltd","Consumer Goods",125000000,22000000,10,6500000,4200000,12000000,28000000,10000000))
        cid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.executemany("""INSERT INTO comparables
        (company_id,peer_name,revenue_multiple,ebitda_multiple)
        VALUES (?,?,?,?,?)""", [
            (cid,"Market Peer A",2.4,11.5),
            (cid,"Market Peer B",2.8,12.2),
            (cid,"Market Peer C",2.6,10.8)
        ])
    conn.commit()
    conn.close()

def valuation(c):
    growth = c["growth"] / 100
    # Five-year DCF with a simple 11% discount rate and 3% terminal growth.
    wacc, terminal_growth = 0.11, 0.03
    fcf0 = c["ebitda"] - c["capex"] - c["working_capital"]
    pv = 0
    projections = []
    for year in range(1, 6):
        fcf = fcf0 * ((1 + growth) ** year)
        pv_fcf = fcf / ((1 + wacc) ** year)
        pv += pv_fcf
        projections.append((year, fcf, pv_fcf))
    terminal_fcf = fcf0 * ((1 + growth) ** 5) * (1 + terminal_growth)
    terminal = terminal_fcf / (wacc - terminal_growth)
    pv_terminal = terminal / ((1 + wacc) ** 5)
    enterprise = pv + pv_terminal
    equity = enterprise + c["cash"] - c["debt"]
    dcf_per_share = equity / c["shares"] if c["shares"] else 0

    return {
        "enterprise": enterprise, "equity": equity,
        "per_share": dcf_per_share, "pv_fcf": pv,
        "pv_terminal": pv_terminal, "projections": projections
    }

@app.route("/")
def dashboard():
    conn = get_db()
    companies = conn.execute("SELECT * FROM companies ORDER BY id DESC").fetchall()
    conn.close()
    data = [(c, valuation(c)) for c in companies]
    return render_template("dashboard.html", companies=data)

@app.route("/companies")
def companies():
    conn = get_db()
    rows = conn.execute("SELECT * FROM companies ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("companies.html", companies=[(c, valuation(c)) for c in rows])

@app.route("/companies/new", methods=["GET","POST"])
def new_company():
    if request.method == "POST":
        try:
            vals = (
                request.form["name"].strip(), request.form["sector"].strip(),
                float(request.form["revenue"]), float(request.form["ebitda"]),
                float(request.form["growth"]), float(request.form["capex"]),
                float(request.form["working_capital"]), float(request.form["cash"]),
                float(request.form["debt"]), float(request.form["shares"])
            )
            if not vals[0] or not vals[1] or any(v < 0 for v in vals[2:]):
                raise ValueError
            conn = get_db()
            conn.execute("""INSERT INTO companies
            (name,sector,revenue,ebitda,growth,capex,working_capital,cash,debt,shares)
            VALUES (?,?,?,?,?,?,?,?,?,?)""", vals)
            conn.commit(); conn.close()
            flash("Company added successfully.", "success")
            return redirect(url_for("companies"))
        except (ValueError, KeyError):
            flash("Please enter valid non-negative financial inputs.", "danger")
    return render_template("company_form.html")

@app.route("/companies/<int:cid>/delete", methods=["POST"])
def delete_company(cid):
    conn = get_db()
    conn.execute("DELETE FROM comparables WHERE company_id=?", (cid,))
    conn.execute("DELETE FROM companies WHERE id=?", (cid,))
    conn.commit(); conn.close()
    flash("Company deleted.", "success")
    return redirect(url_for("companies"))

@app.route("/valuation/<int:cid>")
def valuation_view(cid):
    conn = get_db()
    company = conn.execute("SELECT * FROM companies WHERE id=?", (cid,)).fetchone()
    peers = conn.execute("SELECT * FROM comparables WHERE company_id=?", (cid,)).fetchall()
    conn.close()
    if not company:
        return "Company not found", 404
    v = valuation(company)
    avg_rev = sum(p["revenue_multiple"] for p in peers)/len(peers) if peers else 0
    avg_ebitda = sum(p["ebitda_multiple"] for p in peers)/len(peers) if peers else 0
    comp_revenue = company["revenue"] * avg_rev
    comp_ebitda = company["ebitda"] * avg_ebitda
    return render_template("valuation.html", company=company, v=v, peers=peers,
                           avg_rev=avg_rev, avg_ebitda=avg_ebitda,
                           comp_revenue=comp_revenue, comp_ebitda=comp_ebitda)

@app.route("/peers/<int:cid>", methods=["GET","POST"])
def peers(cid):
    if request.method == "POST":
        try:
            vals = (cid, request.form["peer_name"].strip(),
                    float(request.form["revenue_multiple"]),
                    float(request.form["ebitda_multiple"]))
            if not vals[1] or vals[2] < 0 or vals[3] < 0:
                raise ValueError
            conn = get_db()
            conn.execute("""INSERT INTO comparables
            (company_id,peer_name,revenue_multiple,ebitda_multiple)
            VALUES (?,?,?,?)""", vals)
            conn.commit(); conn.close()
            flash("Comparable company added.", "success")
        except (ValueError, KeyError):
            flash("Enter valid comparable-company data.", "danger")
        return redirect(url_for("valuation_view", cid=cid))
    return redirect(url_for("valuation_view", cid=cid))

@app.route("/peers/<int:peer_id>/delete", methods=["POST"])
def delete_peer(peer_id):
    conn = get_db()
    peer = conn.execute("SELECT company_id FROM comparables WHERE id=?", (peer_id,)).fetchone()
    if peer:
        cid = peer["company_id"]
        conn.execute("DELETE FROM comparables WHERE id=?", (peer_id,))
        conn.commit(); conn.close()
        flash("Comparable removed.", "success")
        return redirect(url_for("valuation_view", cid=cid))
    conn.close()
    return redirect(url_for("companies"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
