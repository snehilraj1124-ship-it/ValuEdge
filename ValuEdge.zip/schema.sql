CREATE TABLE companies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    sector TEXT NOT NULL,
    revenue REAL NOT NULL,
    ebitda REAL NOT NULL,
    growth REAL NOT NULL,
    capex REAL NOT NULL,
    working_capital REAL NOT NULL,
    cash REAL NOT NULL,
    debt REAL NOT NULL,
    shares REAL NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE comparables (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    peer_name TEXT NOT NULL,
    revenue_multiple REAL NOT NULL,
    ebitda_multiple REAL NOT NULL,
    FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
);
